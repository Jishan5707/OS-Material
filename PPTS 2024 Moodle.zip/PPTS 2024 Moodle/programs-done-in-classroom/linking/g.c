int g(int x) {
	return x + 10;
}
