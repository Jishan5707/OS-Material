int main() {
	int *p = 9999;
	*p = 200;
}
